Privacy Policy for DuoSub
Last updated: December 27, 2025
1. Information Collection DuoSub collects the user-provided API Key and UI theme preferences. These are stored locally on the user's device using chrome.storage.local.
2. Use of Information The API Key is used solely to authenticate and process subtitle translations via the user's own Google Apps Script. We do not transmit this key to any third party except the Google-hosted script URL provided by the user.
3. Data Storage All data is stored locally in the browser. We do not have access to your personal files, translation history, or identity.
4. Changes to This Policy We may update our Privacy Policy from time to time.
Contact: duosubmail@gmail.com
